// Interactive JavaScript for MS FIRE SAFETY website
document.addEventListener('DOMContentLoaded', function () {
    // 1. Marquee ticker infinite duplicate
    const marqueeContainer = document.querySelector('.s_announcement_scroll_marquee_container');
    if (marqueeContainer) {
        const item = marqueeContainer.querySelector('.s_announcement_scroll_marquee_item');
        if (item) {
            // Duplicate 3 times for seamless infinite looping
            for (let i = 0; i < 3; i++) {
                const clone = item.cloneNode(true);
                clone.setAttribute('aria-hidden', 'true');
                marqueeContainer.appendChild(clone);
            }
        }
    }

    // 2. Search Modal Handling
    const searchBtns = document.querySelectorAll('.o_search_btn, [title="Search"]');
    const searchModal = document.getElementById('siteSearchModal');
    const searchInput = document.getElementById('siteSearchInput');
    const searchClose = document.getElementById('siteSearchClose');
    const searchResults = document.getElementById('siteSearchResults');

    function openSearch() {
        if (searchModal) {
            searchModal.classList.add('active');
            if (searchInput) {
                searchInput.value = '';
                searchInput.focus();
            }
            if (searchResults) searchResults.innerHTML = '';
        }
    }

    function closeSearch() {
        if (searchModal) {
            searchModal.classList.remove('active');
        }
    }

    searchBtns.forEach(btn => {
        btn.addEventListener('click', function (e) {
            e.preventDefault();
            openSearch();
        });
    });

    if (searchClose) {
        searchClose.addEventListener('click', closeSearch);
    }
    if (searchModal) {
        searchModal.addEventListener('click', function (e) {
            if (e.target === searchModal) closeSearch();
        });
    }

    // Live search within page items
    if (searchInput && searchResults) {
        const searchableItems = [
            { title: "फायर सिलेंडर रिफिलिंग (Refilling Cylinder)", link: "index.html#features", desc: "Refilling of ABC, CO2, Foam, Water fire extinguishers in Kuchaman City." },
            { title: "फायर सिलेंडर रिपेयर एवं रिप्लेसमेंट (Repair & Replacement)", link: "index.html#features", desc: "Inspection, servicing, valve replacement and testing." },
            { title: "नए फायर सिलेंडर की खरीदारी (New Fire Cylinders)", link: "index.html#selection", desc: "Buy ABC Dry Powder, CO2, Foam & Clean Agent Extinguishers." },
            { title: "फायर हाइड्रेंट एवं स्प्रिंकलर सिस्टम (Fire Hydrant & Sprinkler)", link: "index.html#hydrant", desc: "Installation for buildings, schools, factories, and commercial complexes." },
            { title: "अंडरग्राउंड फायर पाइपलाइन (Underground Fire Line)", link: "index.html#selection", desc: "High pressure pipeline network installation and testing." },
            { title: "संपर्क / Contact Manohar Lal", link: "contactus.html", desc: "Sikar Road, Kuchaman City, Rajasthan. Mo: 6378647799" },
            { title: "Frequently Asked Questions (FAQ)", link: "index.html#faq", desc: "Why fire safety is essential and how to choose the right cylinder." }
        ];

        searchInput.addEventListener('input', function () {
            const q = this.value.trim().toLowerCase();
            if (!q) {
                searchResults.innerHTML = '<p class="text-muted small">Type a keyword like "refilling", "cylinder", "hydrant", "contact"...</p>';
                return;
            }
            const filtered = searchableItems.filter(item => 
                item.title.toLowerCase().includes(q) || 
                item.desc.toLowerCase().includes(q)
            );
            if (filtered.length === 0) {
                searchResults.innerHTML = '<p class="text-danger small">No results found for "' + q + '". Please call +91 6378647799 directly.</p>';
            } else {
                let html = '<div class="list-group list-group-flush">';
                filtered.forEach(item => {
                    html += `
                        <a href="${item.link}" class="list-group-item list-group-item-action py-2" onclick="document.getElementById('siteSearchModal').classList.remove('active')">
                            <div class="fw-bold">${item.title}</div>
                            <div class="small text-muted">${item.desc}</div>
                        </a>
                    `;
                });
                html += '</div>';
                searchResults.innerHTML = html;
            }
        });
    }

    // 3. Quick Contact Form Submission to WhatsApp / Thank You page
    const contactForms = document.querySelectorAll('.js-contact-form');
    contactForms.forEach(form => {
        form.addEventListener('submit', function (e) {
            e.preventDefault();
            const name = (form.querySelector('[name="name"]') || {}).value || '';
            const phone = (form.querySelector('[name="phone"]') || {}).value || '';
            const service = (form.querySelector('[name="service"]') || {}).value || '';
            const message = (form.querySelector('[name="message"]') || {}).value || '';

            const waMsg = encodeURIComponent(
                `Namaste MS Fire Safety,\nMy Name: ${name}\nPhone: ${phone}\nRequirement: ${service}\nMessage: ${message}`
            );
            window.open(`https://wa.me/916378647799?text=${waMsg}`, '_blank');
            window.location.href = 'contactus-thank-you.html';
        });
    });
});
